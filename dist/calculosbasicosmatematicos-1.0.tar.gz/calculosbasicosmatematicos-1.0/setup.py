from setuptools import setup

setup(
    name="calculosbasicosmatematicos",
    version="1.0",
    description="Paquete para cálculos básicos: suma, resta, multiplicación y división",
    auhtor="David",
    author_mail="despedidachicho@hotmail.com",
    url="www.pildorasinformaticas.es",
    packages=["moduloMatematico","moduloMatematico.calculosBasicos"]

)